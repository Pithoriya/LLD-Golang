package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"
	//"strings"
	"go/src/LLD-Golang/TickTakToe/Database"
	"go/src/LLD-Golang/TickTakToe/Board"
	"go/src/LLD-Golang/TickTakToe/Constants"
	"go/src/LLD-Golang/TickTakToe/Services/PlayerServices"
)
func main(){
	Database.Init()
	fmt.Println("Enter the total number of players")
	Scanner := bufio.NewScanner(os.Stdin)
	Scanner.Scan()
	TotalNumberOfPlayers,_ := strconv.ParseInt(Scanner.Text(), 10, 32)
	PlayerServices.Init(TotalNumberOfPlayers)
	GetUserDetails(Scanner)
	PlayGame(Scanner)
}

func GetUserDetails(Scanner *bufio.Scanner){
	fmt.Println("Enter their pieces and names")
	for player := 1; player <= int(PlayerServices.GetTotalNumberOfPlayers()); player++ {
		Scanner.Scan()
		Inputs := strings.Split(Scanner.Text(), " ")
		if(len(Inputs) != 2){
			fmt.Println("Invalid move")
			player--
			continue
		}
		piece := Inputs[0]
		userName := Inputs[1]
		if Database.IsPieceExist(piece) {
			fmt.Println("piece is already exist")
			player--
			continue
		}

		if Database.IsUserNameExist(userName) {
			fmt.Println("user name is already exist")
			player--
			continue
		}

		Database.AddUser(userName)
		Database.AddPiece(piece)
		if piece == "X" {
			PlayerServices.AddPlayerWhoWillStart(userName, piece)
		}else{
			PlayerServices.AddPlayer(userName, piece)
		}
	}
}

func PlayGame(Scanner *bufio.Scanner){
	fmt.Println("Game Started")
	bd := Board.CreateBoard(Constants.SIZE)
	bd.PrintMe()
	ind := 0
	for {
		Scanner.Scan()
		Inputs := strings.Split(Scanner.Text(), " ")
		if(len(Inputs) != 2){
			fmt.Println("Invalid move")
			continue
		}
		Ply := PlayerServices.GetPlayer(ind%int(PlayerServices.GetTotalNumberOfPlayers()))
		x,_ := strconv.ParseInt(Inputs[0], 10, 64)
		y,_ := strconv.ParseInt(Inputs[1], 10, 64)
		if x >= 1 && x <=  bd.GetSize() && y >= 1 && y <= bd.GetSize(){
			if bd.IsMoveValid(x, y){
				bd.SetCellValue(x ,y, Ply.GetPiece())
				bd.PrintMe()
			}else{
				fmt.Println("Invalid move")
				continue
			}
		}else{
			fmt.Println("Invalid Move")
			continue
		}

		if bd.IsPlayerWon(x, y, Ply.GetPiece()){
			fmt.Printf("%s won!!", Ply.GetName())
			break
		}
		if bd.IsBoardFull(){
			fmt.Println("Game Is over")
			break
		}
		ind++
	}

}