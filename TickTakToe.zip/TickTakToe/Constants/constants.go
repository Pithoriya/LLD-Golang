package Constants

const(
	SIZE = 3
	EMPTY = "-"
)