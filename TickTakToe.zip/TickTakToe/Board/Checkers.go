package Board

import(
	"go/src/LLD-Golang/TickTakToe/Constants"
)

func (b *board)IsMoveValid(x int64, y int64) bool {
	return b.isCellEmpty(x, y)
}

func (b *board)isCellEmpty(x int64, y int64) bool {
	return b.matrix[x-1][y-1].GetCellValue() == Constants.EMPTY
}


func(b *board)IsBoardFull() bool{
	return b.TotalEmptyCell == 0
}

func(b *board)IsPlayerWon(x int64, y int64, piece string) bool{
	if !b.RowInfo[x-1].IsInterrupted && b.RowInfo[x-1].GetCountValue() == Constants.SIZE{
		return true
	}
	if !b.ColInfo[y-1].IsInterrupted && b.RowInfo[y-1].GetCountValue() == Constants.SIZE{
		return true
	}
	if !b.Diagonal1.IsInterrupted && b.Diagonal1.GetCountValue() == Constants.SIZE{
		return true
	}
	if !b.Diagonal2.IsInterrupted && b.Diagonal2.GetCountValue() == Constants.SIZE{
		return true
	}
	return false
}
