package Board

import(
	"go/src/LLD-Golang/TickTakToe/Constants"
)

func (b *board)SetCellValue(x int64, y int64, val string){
	b.TotalEmptyCell--
	b.matrix[x-1][y-1].SetCellValue(val)
	b.RowInfo[x-1].SetPair(val)
	b.ColInfo[y-1].SetPair(val)
	if x == y{
		b.Diagonal1.SetPair(val)
	}else if x+y-1 == Constants.SIZE{
		b.Diagonal2.SetPair(val)
	}
}