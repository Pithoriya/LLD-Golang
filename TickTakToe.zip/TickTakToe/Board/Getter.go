package Board

func (b *board)GetSize() int64{
	return b.Size
}