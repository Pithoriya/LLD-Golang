package Board

import(
	"fmt"
)
func (b *board)PrintMe(){
	for ind := 0; ind < int(b.Size); ind++ {
		for ind2 := 0; ind2 < int(b.Size); ind2++{
			fmt.Printf("%s ", b.matrix[ind][ind2].GetCellValue())
		}
		fmt.Print("\n")
	}
}