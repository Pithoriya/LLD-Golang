package Board

import (
	"go/src/LLD-Golang/TickTakToe/models/Cell"
	"go/src/LLD-Golang/TickTakToe/models/Pair"
	"go/src/LLD-Golang/TickTakToe/Constants"
)

type board struct{
	Size             int64
	TotalEmptyCell   int64
	matrix           [][]*Cell.Cell
	RowInfo, ColInfo []*Pair.Pair
    Diagonal1, Diagonal2 *Pair.Pair
}

func CreateBoard(Size int64) *board{

	bd := &board{
		Size: Size,
		TotalEmptyCell: Size*Size,
		matrix: make([][]*Cell.Cell, Size),
		RowInfo: make([]*Pair.Pair, Size),
		ColInfo: make([]*Pair.Pair, Size),
	}

	for ind := 0; ind < int(Size); ind++{
		bd.matrix[ind] = make([]*Cell.Cell, Size)
		bd.RowInfo[ind] = Pair.CreatePair()
		bd.ColInfo[ind] = Pair.CreatePair()

		for ind2 := 0; ind2 < int(Size); ind2++{
			bd.matrix[ind][ind2] = Cell.CreateCell(Constants.EMPTY)
		}
	}

	bd.Diagonal1 = Pair.CreatePair()
	bd.Diagonal2 = Pair.CreatePair()
	return bd
}