package Pair

import (
	"go/src/LLD-Golang/TickTakToe/Constants"
)

type Pair struct{
	leadingPiece  string
	count         int64
	IsInterrupted bool
}

func CreatePair() *Pair{
	return &Pair{
		leadingPiece: Constants.EMPTY,
		count : 0,
		IsInterrupted: false,
	}
}

func(p *Pair) GetLeadingPiece() string {
	return p.leadingPiece
}

func(p *Pair) SetLeadingPiece(piece string){
	p.leadingPiece = piece
}

func(p *Pair)GetCountValue() int64{
	return p.count
}

func(p *Pair)IncrementCount(){
	p.count++
}

func (p *Pair)IsInterupted() bool{
	return p.IsInterrupted
}

func(p *Pair)SetInterrupted(){
	p.IsInterrupted = true
}

func(p *Pair)SetPair(val string){
	if p.GetCountValue() == 0{
		p.SetLeadingPiece(val)
	}
	if p.GetLeadingPiece() == val {
		p.IncrementCount()
	} else {
		p.SetInterrupted()
	}
}