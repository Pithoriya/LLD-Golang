package Cell

type Cell struct{
	value string
}

func CreateCell(value string) *Cell{ 
	return &Cell{value: value}
}

func (c *Cell) GetCellValue() string {
	return c.value
}

func (c *Cell) SetCellValue(value string){
	c.value = value
}