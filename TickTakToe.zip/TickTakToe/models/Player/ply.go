package Player

import(

)

type Player struct{
	name string
	piece string
}

func CreatPlayerObject(userName string, piecevalue string) *Player{
	return &Player{
		name: userName,
		piece: piecevalue,
	}
}

func (p *Player)GetName() string{
	return p.name
}

func (p *Player)GetPiece() string{
	return p.piece
}
