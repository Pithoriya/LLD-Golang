package PlayerServices

import (
	"go/src/LLD-Golang/TickTakToe/models/Player"
)
var(
	players []*Player.Player
	totalPlayers int64
)
func Init(TotalPlayer int64){
	totalPlayers = TotalPlayer
	players = make([]*Player.Player, 1)
}

func AddPlayer(userName string, Piece string){
	player := Player.CreatPlayerObject(userName, Piece)
	players = append(players, player)
}

func AddPlayerWhoWillStart(userName string, Piece string){
	player := Player.CreatPlayerObject(userName, Piece)
	players[0] = player
}

func GetPlayer(ind int)*Player.Player {
	return players[ind]
}

func GetTotalNumberOfPlayers() int{
	return int(totalPlayers)
}