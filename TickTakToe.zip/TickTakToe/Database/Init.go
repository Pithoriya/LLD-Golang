package Database

import "strings"

var (
	userData map[string]bool
    pieces map[string]bool
)

func Init(){
	userData = make(map[string]bool)
	pieces = make(map[string]bool)
}

func IsUserNameExist(userName string) bool {
	_, prs := userData[strings.ToUpper(userName)]
	return prs
}

func IsPieceExist(Piece string) bool {
	_, prs := pieces[strings.ToUpper(Piece)]
	return prs
}

func AddUser(userName string) {
	userData[strings.ToUpper(userName)] = true
}

func AddPiece(piece string) {
	pieces[strings.ToUpper(piece)] = true
}